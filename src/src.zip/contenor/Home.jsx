





import React from 'react';
import Questions from './questions'



class Home extends React.Component {
    constructor() {
        super()
        this.state = {
            start: false
        }
    }


    click = () => {
        this.setState({
            start: true
        })
    }
    render() {
        return (

            <div>


                    <div >
                        <div className="col s12 m5">
                            <div className="card-panel teal">
                                <span className="white-text">  <h3>Descrption:</h3> <p>
                                    Basic React quiz covering All chapters of a Smarter way to Learn React book. Important Note: Where specifically noted, you can select more than one option as a correct answer. For example, you can select a, b, and c as the correct answer.
        </p>

                                    <p>Passing Score:  <h5> 70 </h5></p>
                                    <p>Quiz Duration:  <h5> 10 Minutes</h5></p>
                                    <p>No Of Attamp Of:  <h5>0</h5></p>
                                    <a className="waves-effect waves-light btn" onClick={() => this.props.click()} >Start Quiz</a>

                                </span>

                            </div>
                        </div>
                    </div>
                }


            </div>

        )
    }
}
export default Home;