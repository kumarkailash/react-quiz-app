import React from 'react';
import Button from './button'
import { facebookLogin } from '../config/fuction'



class Nevbar extends React.Component {
  constructor(props) {
    super(props)

  }

  login = async () => {
    try {
      let user = await facebookLogin()
      console.log('working==>', user)
      this.props.getRes(true)
    }

    catch (err) {
      console.log(err)

    }

  }

  render() {

    return (

      <div>
        <nav>
          <div className="nav-wrapper">
            <a href="#!" className="logo" >Welcome to Quiz App </a>
            <ul className="right">

              <li><a className="btn-large" onClick={this.login} >Log In With Facebook</a></li>
            </ul>
          </div>
        </nav>

        <h1 className='heading' > Welcome to Quiz App  </h1>

      </div>




    )
  }
}
export default Nevbar;