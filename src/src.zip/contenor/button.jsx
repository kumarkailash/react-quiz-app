import React from 'react';

import fblogo from './../images/facebookicon.jpg'

class Button extends React.Component{
    constructor(){
        super()
    }

    render(){
        return(

<div>

<center>
<button className="waves-effect waves-light btn-large" onClick={()=>this.props.click()} > <img width="30px" src={fblogo} alt="facebook login"/>
 Login with facebook </button></center>

    
</div>



        )
    }
}
export default Button;