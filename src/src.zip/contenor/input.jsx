import React from 'react';



class Input extends React.Component{
    constructor(){
        super()
    }

    render(){
        return(

<div>
<h1>welcome to Input</h1>
</div>

        )
    }
}
export default Input;