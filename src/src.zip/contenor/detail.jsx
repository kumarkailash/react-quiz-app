





import React from 'react';


class Detail extends React.Component {
    constructor() {
        super()
    
    }


    render() {
        return (

            <div>

<h1>detail</h1>

            </div>

        )
    }
}
export default Detail;