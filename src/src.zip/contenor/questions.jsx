import React from 'react';
import {api} from '../config/fuction'


class Questions extends React.Component{
    constructor(){
        super()
        this.state = {
            data: '',
            counter : 0,
            checked:true
          };
          this.next = this.next.bind(this)
    }


    async componentDidMount() {
        let {counter} = this.state
    
    let data = await api()
    console.log(data)
    data[counter].incorrect_answers.push(data[counter].correct_answer)
    this.setState({
        data : data,
        allAnswer : data[counter].incorrect_answers
    })
      }
      next(){
        let {data,counter} = this.state
        data[counter + 1].incorrect_answers.push(data[counter + 1].correct_answer)
        this.setState({
              counter : counter + 1,
              allAnswer : data[counter + 1].incorrect_answers,
              checked:true
        })
      }
    
    render(){
      let {data ,counter,allAnswer} = this.state
      return(

<div>
{console.log(allAnswer)}  

<h6>{data && data[counter].question}</h6>

{data && allAnswer.map((value,index)=> 
<div className="radios">
<table id="rblSex">
      <label>
        <tr>
          <td>
        <input name="group1" value={value} type="radio"  />
        <span>{value}</span></td>
        </tr>
      </label>
      </table>




      
</div>
)}
<center>
<input className=" btn-large" type= 'button' value = 'Next' onClick={this.next} /></center>
</div>

        )
    }
}
export default Questions;