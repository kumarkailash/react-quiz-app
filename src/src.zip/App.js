import React from 'react';
import './App.css';
// import Button from './contenor/button'
// import Questions  from './contenor/questions'
import Nevbar from './contenor/nevbar'

import Home from './contenor/Home'
import Questions from './contenor/questions'
import { Timer } from './config/fuction'
import Detail from './contenor/detail'




class App extends React.Component{
constructor(){
super()
  this.state={
    login:true,
    start : true,
    result: true
  }
}

getRes=(res)=>{
  console.log(res)
this.setState({
  login:false
})
}




timerShow = (res) =>{
alert('hi')
 
setInterval(async()=>{
    try{
      let time = await Timer();
      console.log(time)
      if(time === '0:00'){
        this.setState({
          result : false,

        })
        clearInterval()
      }
      else{
        this.setState({
          Time : time,
          start : false
        })
      }
      
    }
    catch(error){
      console.log(error)
    }
  },1000)
  
}


render(){
return(
<div>
  
<input type='button' value= 'Timer' onClick = {this.timerShow.bind(this)} />
<h1>{this.state.Time}</h1>
  {
     this.state.login ?
    <Nevbar  getRes={this.getRes} />:
    <div>
    {this.state.start ?
    <Home click = {this.timerShow} /> : 
  <div>
    {this.state.result ? 
  
                    <div>
                        <h1 className="waves-effect waves-light btn-large">   Welcomoe to Quiz App  </h1>

                        <Questions />


                    </div> : <Detail />

}
</div>}

             
             </div>}

</div>

  
)

}
}

export default App;